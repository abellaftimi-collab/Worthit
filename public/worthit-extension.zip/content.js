/*
 * Worthit — content script
 * 1) Intercepte les clics sur les boutons d'achat et impose l'écran de pause.
 * 2) Masque (floute) les produits contenant tes mots-clés bloqués dans les pages de résultats.
 * 3) Se synchronise automatiquement avec ton compte quand tu visites ton dashboard Worthit.
 * Réglages : popup de l'extension (wapi.storage.sync) + synchro depuis le site.
 */
(function () {
  'use strict';

  /* Passerelle d'API : Safari expose 'browser', Chrome/Edge exposent 'chrome'.
   * Un seul point d'entrée évite de dupliquer le code par navigateur. */
  const wapi = (typeof browser !== 'undefined' && browser.runtime) ? browser : chrome;

  /* Logo Worthit (bouton pause) — inline pour ne dépendre d'aucun fichier de la page. */
  const LOGO_MARK = '<svg width="18" height="18" viewBox="0 0 100 100" style="display:block;flex-shrink:0;filter:drop-shadow(0 0 10px rgba(167,139,250,.7))"><defs><linearGradient id="wxg" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#a78bfa"/><stop offset="1" stop-color="#7c3aed"/></linearGradient></defs><path fill="url(#wxg)" fill-rule="evenodd" d="M50 6a44 44 0 1 1 0 88 44 44 0 0 1 0-88Zm-9 27a5 5 0 0 0-5 5v24a5 5 0 0 0 10 0V38a5 5 0 0 0-5-5Zm18 0a5 5 0 0 0-5 5v24a5 5 0 0 0 10 0V38a5 5 0 0 0-5-5Z"/></svg>';

  
  
  /* Deux niveaux de certitude, et pas un seul comme avant.
   *
   * MOTS_FORTS : une formulation qui ne veut dire qu'une chose — on est en train de payer.
   * MOTS_FAIBLES : un verbe seul (« Buy », « Acheter », « Order »…). Sur un site immobilier
   *   ou une place de marché, c'est le plus souvent un ONGLET pour parcourir le catalogue.
   *   Zillow a littéralement <a href="/homes/for_sale/">Buy</a> dans sa barre de navigation :
   *   cliquer dessus déclenchait une pause d'achat alors qu'on voulait juste regarder.
   *   Ces mots-là exigent donc un indice supplémentaire (voir estActionDachat).
   * Couvre fr/en/de/es/nl, l'achat en 1 clic, le paiement express et les portefeuilles. */
  const MOTS_FORTS = [
    // français
    'ajouter au panier', 'ajouter à la panier', 'au panier', 'achat en 1 ?-?clic',
    'payer maintenant', 'passer (la |ma )?commande', 'valider (ma |la |mon )?(commande|panier)',
    'finaliser (ma |la )?commande', 'confirmer (la |ma )?commande', 'procéder au paiement',
    // « régler » n'est un paiement que suivi de ce qu'on règle. Seul, il veut d'abord dire
    // résoudre : « régler ça en face », « régler un différend », « régler les paramètres ».
    'régler (ma |mon |mes |la |le )?(commande|panier|achats?|montant|total|facture)',
    // anglais
    'add to (cart|bag|basket|order)', 'buy( it)? now', 'checkout', 'check out',
    'proceed to', 'place( your)? order', 'complete (purchase|order)', 'confirm (order|purchase|payment)',
    'pay now', 'one[- ]click', '1[- ]click',
    // portefeuilles / paiement express
    'apple pay', 'google pay', 'paypal', 'shop pay', 'klarna', 'express checkout', 'paiement express',
    // allemand
    'in den warenkorb', 'jetzt kaufen', 'zur kasse', 'kostenpflichtig bestellen',
    // espagnol
    'añadir a la cesta', 'agregar al carrito', 'comprar ahora', 'realizar pedido', 'finalizar compra',
    // néerlandais
    'in winkelwagen', 'afrekenen', 'nu kopen',
  ];
  const MOTS_FAIBLES = [
    'acheter', 'payer', 'paiement', 'commander', 'je commande',
    'souscrire', "s'abonner", 'réserver', 'louer',
    'buy', 'purchase', 'pay', 'subscribe', 'rent', 'book now', 'order',
    'kaufen', 'bestellen', 'comprar', 'pagar', 'kopen',
  ];
  /* Frontières de mots. Sans elles, « rent » matchait dans pa*rent*s / diffé*rent*s / trans*parent*
   * et déclenchait une pause d'achat sur des liens anodins.
   * Classe explicite (lettres + accents) plutôt que \p{L} : pas de piège d'échappement et
   * compatible avec les moteurs plus anciens (dont Safari). */
  const LETTRE = 'A-Za-zÀ-ÖØ-öø-ÿ';
  const motsEn = (liste) => new RegExp(
    '(?:^|[^' + LETTRE + '])(?:' + liste.join('|') + ')(?:[^' + LETTRE + ']|$)', 'i');
  const ACHAT_FORT = motsEn(MOTS_FORTS);
  const ACHAT_FAIBLE = motsEn(MOTS_FAIBLES);
  // Conservé pour le formulaire et la synchro : « est-ce que ça parle d'achat, au sens large ? »
  const BUY_WORDS_STRICT = motsEn(MOTS_FORTS.concat(MOTS_FAIBLES));

  /* Chemins d'URL qui SONT déjà une étape d'achat (panier, paiement, commande).
   * Arriver directement sur ces pages doit aussi déclencher la pause. */
  const CHECKOUT_PATHS = /(^|\/)(checkout|check-out|panier|cart|basket|warenkorb|winkelwagen|carrito|cesta|commande|order(s)?\/?(new|create)?|bestellung|pedido|paiement|payment|pay|kasse|afrekenen|finalizar-compra|passer-commande)(\/|$|\?)/i;

  // lang vide et non 'fr' : tant que le compte n'a rien synchronisé, i18n.js choisit seul
  // d'après la langue du navigateur. Forcer 'fr' ici imposait le français au monde entier.
  let cfg = { enabled: true, pauseAll: true, hideResults: true, blockSearch: true, blockSites: true, pauseSeconds: 60, strictMode: false, pin: '', premium: false, apiBase: '', lang: '', ctx: null, premiumAuth: null, keywords: [], priceLimit: 0 };

  /* Traduction : i18n.js est chargé juste avant ce fichier (voir le manifest).
   * La langue vient du compte (cfg.lang, synchronisée depuis le site) ; tant qu'elle n'est
   * pas connue, i18n.js part sur celle du navigateur. */
  const wt = (cle, vars) => self.WorthitI18n.t(cle, vars);

  /* Mode strict (parental) : le seul moyen de passer un blocage est le code PIN fixé à
   * l'avance. (Friction volontaire, pas un coffre-fort : une extension reste désinstallable.) */
  function strictActive() {
    return !!(cfg.strictMode && cfg.pin && String(cfg.pin).length);
  }
  /* Champ de saisie du code, réutilisé par les deux pop-ups (achat + recherche). */
  function pinGateHtml(id) {
    return `<div style="margin-top:12px;padding-top:14px;border-top:1px solid rgba(255,255,255,.1);">
      <p style="font-size:11.5px;color:rgba(255,255,255,.45);margin:0 0 8px;text-align:center;">${wt('pin.unlockWith')}</p>
      <div style="display:flex;gap:8px;">
        <input id="${id}-pin" type="password" inputmode="numeric" autocomplete="off" placeholder="••••" style="flex:1;text-align:center;letter-spacing:.3em;background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.15);border-radius:11px;padding:11px;color:#fff;font-family:inherit;font-size:15px;"/>
        <button id="${id}-unlock" style="padding:11px 16px;border-radius:11px;border:none;cursor:pointer;background:rgba(255,255,255,.1);color:#fff;font-size:13px;font-family:inherit;">${wt('pin.unlock')}</button>
      </div>
      <p id="${id}-err" style="font-size:11px;color:#f87171;margin:8px 0 0;text-align:center;height:14px;"></p>
    </div>`;
  }
  function wirePinGate(id, onSuccess) {
    const input = document.getElementById(id + '-pin');
    const btn = document.getElementById(id + '-unlock');
    const err = document.getElementById(id + '-err');
    if (!input || !btn) return;
    const tryUnlock = () => {
      if (String(input.value) === String(cfg.pin)) onSuccess();
      else { err.textContent = wt('pin.wrong'); input.value = ''; input.focus(); }
    };
    btn.addEventListener('click', tryUnlock);
    input.addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); tryUnlock(); } });
  }

  const allowKey = 'worthit_allow_' + location.hostname;

  function isWorthitApp() {
    return document.documentElement.dataset.worthitApp === '1';
  }

  /* ---------- 3) Synchronisation compte → extension (sur le site Worthit uniquement) ---------- */
  function syncFromSite() {
    if (!isWorthitApp()) return;
    try {
      const raw = localStorage.getItem('worthit_ext_sync');
      if (!raw) return;
      const d = JSON.parse(raw);
      if (!d || typeof d !== 'object') return;
      const nextKeywords = Array.isArray(d.keywords) ? d.keywords.map(String).slice(0, 50) : cfg.keywords;
      const nextLimit = Math.max(0, +d.priceLimit || 0);
      // Durée du minuteur : bornée 0–600 s pour éviter toute valeur aberrante venue du site.
      const nextPause = (d.pauseSeconds === undefined) ? cfg.pauseSeconds : Math.min(600, Math.max(0, +d.pauseSeconds || 0));
      // Contexte pour Worthy : statut Premium, URL du serveur, langue, et snapshot budgétaire.
      const nextPremium = (d.premium === undefined) ? cfg.premium : !!d.premium;
      const nextApiBase = (typeof d.apiBase === 'string') ? d.apiBase : cfg.apiBase;
      const nextLang = (typeof d.lang === 'string') ? d.lang : cfg.lang;
      const nextCtx = (d.ctx && typeof d.ctx === 'object') ? d.ctx : cfg.ctx;
      const nextPa = (d.premiumAuth === undefined) ? cfg.premiumAuth : d.premiumAuth;
      // Mode strict (parental) piloté depuis l'appli. Les champs ne sont présents QUE si
      // l'utilisateur y a touché là-bas : sinon un réglage fait ici serait écrasé.
      const nextStrict = (d.strictMode === undefined) ? cfg.strictMode : !!d.strictMode;
      const nextPin = (d.pin === undefined) ? cfg.pin : String(d.pin || '').replace(/\s/g, '').slice(0, 12);
      const change = JSON.stringify(nextKeywords) !== JSON.stringify(cfg.keywords) || nextLimit !== cfg.priceLimit
        || nextPause !== cfg.pauseSeconds || nextPremium !== cfg.premium || nextApiBase !== cfg.apiBase
        || nextLang !== cfg.lang || JSON.stringify(nextCtx) !== JSON.stringify(cfg.ctx)
        || JSON.stringify(nextPa) !== JSON.stringify(cfg.premiumAuth)
        || nextStrict !== cfg.strictMode || nextPin !== cfg.pin;
      if (change) {
        cfg.keywords = nextKeywords;
        cfg.priceLimit = nextLimit;
        cfg.pauseSeconds = nextPause;
        cfg.premium = nextPremium;
        cfg.apiBase = nextApiBase;
        cfg.lang = nextLang;
        self.WorthitI18n.setLang(nextLang);
        cfg.ctx = nextCtx;
        cfg.premiumAuth = nextPa;
        cfg.strictMode = nextStrict;
        cfg.pin = nextPin;
        wapi.storage.sync.set({ worthitCfg: cfg });
      }
      publierEtatVersSite();
    } catch (e) {}
  }

  /* Retour d'information vers l'appli : elle doit pouvoir afficher l'état réel même quand
   * le mode strict a été réglé depuis le popup. On ne renvoie JAMAIS le code lui-même,
   * seulement le fait qu'il en existe un — le site n'a aucune raison de le connaître. */
  function publierEtatVersSite() {
    if (!isWorthitApp()) return;
    try {
      localStorage.setItem('worthit_ext_state', JSON.stringify({
        installee: true,
        strictMode: !!cfg.strictMode,
        hasPin: !!(cfg.pin && String(cfg.pin).length),
        ts: Date.now(),
      }));
    } catch (e) {}
  }
  setTimeout(syncFromSite, 1200);
  setInterval(syncFromSite, 4000);

  /* ---------- 3 bis) Auto-capture des économies quand tu résistes ----------
   * L'extension connaît déjà le prix. Au clic « J'attends », on note une résistance
   * EN ATTENTE. Elle ne devient une économie confirmée qu'après 24 h — et seulement si
   * tu n'as pas acheté le même produit (même URL) entre-temps. Dédup par URL pour que
   * spammer « ajouter au panier → non » ne gonfle rien. Les économies mûries sont versées
   * dans ton compte à ta prochaine visite sur le site Worthit. */
  const MATURE_MS = 24 * 60 * 60 * 1000;       // 24 h avant de compter
  const DEDUP_MS = 30 * 24 * 60 * 60 * 1000;   // même URL : compte une fois par 30 jours

  function urlKey() {
    // On ignore query + hash : la même fiche produit atteinte via des paramètres de suivi
    // différents ne doit compter qu'une fois.
    try { const u = new URL(location.href); return u.origin + u.pathname; }
    catch (e) { return String(location.href).split('?')[0]; }
  }
  function localGet(keys) { return new Promise((res) => wapi.storage.local.get(keys, (r) => res(r || {}))); }
  function localSet(obj) { return new Promise((res) => wapi.storage.local.set(obj, () => res())); }

  async function recordResistance(price) {
    const p = Math.max(0, +price || 0);
    if (p <= 0) return; // sans prix détecté, une « économie » de 0 € n'a aucun sens
    const key = urlKey();
    const now = Date.now();
    const { worthit_pending = {}, worthit_matured = [] } = await localGet(['worthit_pending', 'worthit_matured']);
    if (worthit_pending[key]) return;                                              // déjà en attente
    if (worthit_matured.some((m) => m.key === key && now - m.ts < DEDUP_MS)) return; // déjà compté récemment
    worthit_pending[key] = { price: p, ts: now, hostname: location.hostname, title: (document.title || '').slice(0, 80) };
    await localSet({ worthit_pending });
  }
  async function cancelResistance() {
    const key = urlKey();
    const { worthit_pending = {} } = await localGet(['worthit_pending']);
    if (worthit_pending[key]) { delete worthit_pending[key]; await localSet({ worthit_pending }); }
  }
  async function matureSweep() {
    const now = Date.now();
    const { worthit_pending = {}, worthit_matured = [] } = await localGet(['worthit_pending', 'worthit_matured']);
    let changed = false;
    for (const key of Object.keys(worthit_pending)) {
      const p = worthit_pending[key];
      if (now - p.ts >= MATURE_MS) {
        // id unique (URL + horodatage) : le site s'en sert pour ne jamais compter deux fois.
        worthit_matured.push({ id: key + '|' + p.ts, key, price: p.price, ts: p.ts, hostname: p.hostname, title: p.title });
        delete worthit_pending[key];
        changed = true;
      }
    }
    // Purge des mûries trop vieilles (supposées déjà synchronisées) pour ne pas grossir sans fin.
    const garde = worthit_matured.filter((m) => now - m.ts < DEDUP_MS + MATURE_MS);
    if (garde.length !== worthit_matured.length) changed = true;
    if (changed) await localSet({ worthit_pending, worthit_matured: garde });
  }
  async function reportMaturedToSite() {
    if (!isWorthitApp()) return;
    const { worthit_matured = [], worthit_pending = {} } = await localGet(['worthit_matured', 'worthit_pending']);
    try {
      localStorage.setItem('worthit_savings_inbox', JSON.stringify(worthit_matured));
      // Les résistances ENCORE en attente : le site s'en sert pour prévenir l'utilisateur
      // qu'un achat est déjà suivi, et lui éviter de le saisir une seconde fois à la main.
      localStorage.setItem('worthit_savings_pending', JSON.stringify(
        Object.keys(worthit_pending).map((k) => ({
          price: worthit_pending[k].price,
          title: worthit_pending[k].title,
          hostname: worthit_pending[k].hostname,
          ts: worthit_pending[k].ts,
        }))
      ));
    } catch (e) {}
  }
  /* Le site accuse réception des économies qu'il a créditées : on les retire alors de la file,
   * pour qu'elles ne soient jamais recomptées. */
  async function consumeAck() {
    if (!isWorthitApp()) return;
    let ack;
    try { ack = JSON.parse(localStorage.getItem('worthit_savings_ack') || '[]'); } catch (e) { return; }
    if (!Array.isArray(ack) || !ack.length) return;
    const ackSet = new Set(ack);
    const { worthit_matured = [] } = await localGet(['worthit_matured']);
    const reste = worthit_matured.filter((m) => !ackSet.has(m.id));
    if (reste.length !== worthit_matured.length) await localSet({ worthit_matured: reste });
  }
  matureSweep();
  setInterval(matureSweep, 60000);
  setTimeout(() => { reportMaturedToSite(); consumeAck(); }, 1500);
  setInterval(() => { reportMaturedToSite(); consumeAck(); }, 5000);

  /* ---------- 2) Masquage des produits contenant un mot-clé bloqué ---------- */
  let styleInjected = false;
  function injectStyle() {
    if (styleInjected) return;
    styleInjected = true;
    const st = document.createElement('style');
    st.textContent = '.worthit-masked{filter:blur(10px) grayscale(.65) !important;opacity:.4 !important;pointer-events:none !important;user-select:none !important;transition:filter .3s ease;}';
    document.documentElement.appendChild(st);
  }
  const MASK_LIMIT = 80; // garde-fou : au plus 80 nouvelles fiches masquées par passage
  /* Texte représentatif d'un lien. Beaucoup de fiches produit ne contiennent qu'une image :
   * sans aria-label / title / alt, elles seraient totalement invisibles pour le filtre. */
  function linkText(a) {
    // textContent et non innerText : innerText force un recalcul de mise en page à chaque
    // lien, ce qui coûte cher sur une grille de 50 produits relue à chaque changement.
    const img = a.querySelector('img[alt]');
    // On CONCATÈNE au lieu de n'utiliser l'aria-label qu'en dernier recours : sur Nike,
    // le lien de l'image porte le nom du produit dans son aria-label alors que son texte
    // visible ne contient qu'un badge (« Meilleure vente ») — le mot-clé passait à travers.
    const t = [
      (a.textContent || '').trim(),
      a.getAttribute('aria-label') || '',
      a.getAttribute('title') || '',
      (img && img.getAttribute('alt')) || '',
    ].join(' ').replace(/\s+/g, ' ').trim();
    return t.slice(0, 300).toLowerCase();
  }

  /* Remonte du lien jusqu'à la VRAIE fiche produit.
   * Beaucoup de boutiques (Nike, Zalando…) découpent une fiche en deux liens : un pour
   * l'image, un pour le titre. Masquer celui de l'image ne floutait que la photo et
   * laissait le nom et le prix parfaitement lisibles — soit précisément ce qu'il fallait
   * cacher. On remonte donc tant que le conteneur ne porte quasiment aucun texte. */
  const SEL_CARTE = 'li,article,[class*="product" i],[class*="item" i],[class*="card" i],[data-testid*="card" i]';
  function tropGrand(el) {
    const r = el.getBoundingClientRect();
    return r.width > window.innerWidth * 0.92 && r.height > window.innerHeight * 0.7;
  }
  function carteDe(a) {
    let card = a.closest(SEL_CARTE) || a;
    for (let i = 0; i < 4 && card.parentElement; i++) {
      const parent = card.parentElement;
      if (tropGrand(parent)) break;                              // on ne floute jamais la page
      if ((parent.textContent || '').trim().length > 600) break; // un article, pas une fiche
      // Critère d'arrêt : le parent rassemble-t-il PLUSIEURS entrées distinctes ?
      // On regarde vers quoi pointent ses enfants directs. Une grille de produits ou une
      // liste de résultats mène vers des cibles différentes → on s'arrête à l'entrée
      // courante. Une fiche, elle, a beau contenir deux liens (image + titre), ils mènent
      // au MÊME produit → on peut continuer à remonter jusqu'à elle.
      // (Tolérance à 2 : une fiche porte parfois un lien de variante en plus.)
      const cibles = new Set();
      for (const enfant of parent.children) {
        const lien = enfant.matches('a[href]') ? enfant : enfant.querySelector('a[href]');
        if (lien) cibles.add(lien.getAttribute('href'));
      }
      if (cibles.size > 2) break;
      card = parent;
    }
    return card;
  }
  function maskProducts() {
    if (!cfg.enabled || !cfg.hideResults || !(cfg.keywords || []).length) return;
    if (isWorthitApp()) return;
    const kws = cfg.keywords.map(k => String(k).toLowerCase()).filter(Boolean);
    if (!kws.length) return;
    injectStyle();
    // Budget PAR PASSAGE, et non cumulé sur la page. Le plafond cumulé condamnait le
    // défilement infini : passé 80 fiches masquées, tout ce qui se chargeait ensuite
    // s'affichait en clair. Le rôle du plafond est d'empêcher un passage de s'emballer,
    // pas d'arrêter de protéger au bout d'un moment.
    let budget = MASK_LIMIT;
    // Sur le site bloqué lui-même, TOUS les liens pointent vers le domaine : inclure l'URL
    // floutrait jusqu'au menu et au pied de page. Ailleurs (Google, Amazon…), l'URL est
    // justement l'information la plus fiable — le lien « Chaussures » ne dit pas « nike »
    // mais pointe vers nike.com.
    const surLeDomaine = kws.some((k) => domaineCourant().includes(k));
    const links = document.querySelectorAll('a');
    let juges = 0;
    for (const a of links) {
      let t = linkText(a);
      // L'URL ne compte que pour les liens qui SORTENT du site courant. Sur une page de
      // résultats pour « puma », l'adresse de la page contient déjà le mot : tous les liens
      // internes (menu, filtres, recherches associées) le contiennent donc aussi, et on
      // floutait l'interface entière. Un lien interne reste jugé sur son texte.
      if (!surLeDomaine && a.href && a.origin && a.origin !== location.origin) {
        const url = a.href.toLowerCase();
        if (!url.startsWith('javascript:')) t = t ? t + ' ' + url : url;
      }
      if (!t) continue;
      // Signature du libellé plutôt qu'un drapeau « déjà vu » définitif : sur un site qui
      // remplit ses titres après coup (React, chargement différé), un lien inspecté trop tôt
      // était marqué et plus JAMAIS réexaminé, même une fois son nom de produit arrivé.
      const sig = t.length + '|' + t.slice(0, 40);
      if (a.dataset.worthitSig === sig) continue;   // déjà jugé sur ce texte : ne coûte rien
      a.dataset.worthitSig = sig;
      // Le plafond ne compte QUE le travail réel. Avant, il comptait chaque lien relu,
      // donc au-delà de 1500 liens sur la page — vite atteint en défilement infini —
      // les nouveaux produits, situés en fin de document, n'étaient jamais examinés.
      if (juges++ > 400) break;
      const hit = kws.find(k => t.includes(k));
      if (!hit) continue;
      const card = carteDe(a);
      // On teste la classe, pas un attribut à nous : quand la boutique réécrit className
      // (re-rendu React), le floutage saute et doit être remis — pas considéré comme déjà fait.
      if (card.classList.contains('worthit-masked')) continue;
      if (tropGrand(card)) continue;
      card.dataset.worthitMasked = '1';
      card.classList.add('worthit-masked');
      card.title = wt('o.masked', { mot: hit });
      if (--budget <= 0) break;
    }

    if (budget > 0) budget = masquerFichesSansLien(kws, budget);
    // Budget épuisé : on rend la main pour ne pas figer la page, et on reprend juste
    // après — sinon le reste de la grille resterait en clair jusqu'au prochain événement.
    if (budget <= 0) setTimeout(maskProducts, 250);
  }

  /* Un prix : la signature d'une fiche produit. Sert de garde-fou à la passe ci-dessous,
   * pour ne pas flouter un paragraphe qui mentionne simplement la marque.
   * « eur » n'est reconnu qu'entouré de frontières de mot, sinon « 3 meilleurs » passerait. */
  const PRIX = /(?:\d[\d\s.,]*\s?[€£$])|(?:[€£$]\s?\d)|(?:\d[\d\s.,]*\s?\b(?:eur|euros?|usd|gbp)\b)/i;
  const PRIX_TOUS = new RegExp(PRIX.source, 'gi');
  // Conteneurs de page : jamais une fiche produit, quoi qu'ils contiennent.
  const BALISES_PAGE = /^(?:BODY|HTML|MAIN|NAV|HEADER|FOOTER|ASIDE|FORM)$/;

  /* Deuxième passe : les fiches qui ne sont PAS des liens.
   * Google Shopping construit ses vignettes en <div> rendus cliquables par JavaScript —
   * aucun <a> dans toute la chaîne, donc la passe précédente ne les voyait même pas.
   * On part du texte qui porte le mot-clé et on remonte jusqu'au premier bloc qui contient
   * AUSSI un prix : c'est la fiche, et c'est ce qui évite de flouter n'importe quel texte. */
  function masquerFichesSansLien(kws, budget) {
    const marcheur = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, null);
    let noeud, vus = 0;
    while ((noeud = marcheur.nextNode())) {
      if (vus++ > 4000) break;
      const texte = (noeud.data || '').toLowerCase();
      if (texte.length < 3) continue;
      const hit = kws.find((k) => texte.includes(k));
      if (!hit) continue;
      let el = noeud.parentElement;
      if (!el) continue;
      if (el.closest('a')) continue;                  // déjà couvert par la passe des liens
      if (el.closest('.worthit-masked')) continue;    // déjà sous un flou
      let carte = null;
      for (let i = 0; i < 6 && el; i++) {
        if (BALISES_PAGE.test(el.tagName)) break;     // on ne remonte pas jusqu'à la page
        if (tropGrand(el)) break;                     // ni jusqu'à un bloc plein écran
        const t = (el.textContent || '').trim();
        if (t.length > 600) break;                    // un article, pas une fiche
        const prix = t.match(PRIX_TOUS);
        if (prix) {
          // Plusieurs prix = une LISTE de produits, pas une fiche : on n'a pas trouvé de
          // fiche isolée, mieux vaut ne rien flouter que de flouter tout un bloc.
          // (Une fiche en promo affiche légitimement 2 ou 3 montants.)
          if (prix.length <= 3) carte = el;
          break;
        }
        el = el.parentElement;
      }
      if (!carte || carte.classList.contains('worthit-masked')) continue;
      carte.dataset.worthitMasked = '1';
      carte.classList.add('worthit-masked');
      carte.title = wt('o.masked', { mot: hit });
      if (--budget <= 0) break;
    }
    return budget;
  }
  /* Débounce AVEC plafond. Une page marchande mute en permanence (carrousels, images
   * différées, pubs) : un clearTimeout à chaque mutation repoussait le passage suivant
   * à l'infini, et plus rien n'était masqué après le premier écran. */
  let maskTimer = null, premiereMutation = 0;
  function planifierMasquage() {
    const maintenant = Date.now();
    if (!premiereMutation) premiereMutation = maintenant;
    clearTimeout(maskTimer);
    const attente = (maintenant - premiereMutation > 1500) ? 0 : 400;
    maskTimer = setTimeout(() => {
      premiereMutation = 0;
      if (checkBlockedSite()) return;
      checkBlockedSearch();
      maskProducts();
    }, attente);
  }
  // Seulement childList/subtree : nos propres ajouts de classe et de title sont des
  // mutations d'ATTRIBUTS, donc ils ne se redéclenchent pas eux-mêmes.
  const mo = new MutationObserver(planifierMasquage);
  if (document.body) mo.observe(document.body, { childList: true, subtree: true });
  document.addEventListener('DOMContentLoaded', () => {
    if (document.body) mo.observe(document.body, { childList: true, subtree: true });
    maskProducts();
  });
  // Filet de sécurité : beaucoup de boutiques renseignent les alt/aria-label APRÈS coup.
  // C'est une mutation d'attribut, que l'observateur ci-dessus ne surveille pas — d'où
  // quelques passages espacés pendant le chargement.
  [800, 1500, 3000, 6000, 10000].forEach((d) => setTimeout(maskProducts, d));
  // Le défilement déclenche le chargement différé des grilles : on repasse derrière.
  window.addEventListener('scroll', planifierMasquage, { passive: true });

  /* ---------- 2 bis) Blocage de la recherche elle-même ----------
   * Plus fort que le floutage : si la requête tapée contient un mot-clé bloqué,
   * on masque toute la page de résultats derrière un écran de pause. */
  const SEARCH_PARAMS = ['q', 'k', 'query', 'search', 'search_text', 'searchterm', 'search_query',
    'keyword', 'keywords', 'text', 'term', '_nkw', 'searchtext', 'wd'];
  const searchAllowKey = 'worthit_search_allow_' + location.hostname;

  function currentSearchQuery() {
    try {
      const p = new URLSearchParams(location.search);
      for (const key of SEARCH_PARAMS) {
        const v = p.get(key);
        if (v && v.trim()) return v.trim();
      }
    } catch (e) {}
    // Certains sites mettent la recherche dans le chemin : /search/nike, /recherche/nike
    const m = location.pathname.match(/\/(?:search|recherche|catalogsearch\/result)\/([^/?#]+)/i);
    if (m) { try { return decodeURIComponent(m[1]).replace(/[-+_]/g, ' '); } catch (e) {} }
    const el = document.querySelector('input[type="search"],input[name="q"],input[name="k"]');
    return el && el.value ? el.value.trim() : '';
  }

  function searchAllowedNow() {
    try { return Date.now() < (+sessionStorage.getItem(searchAllowKey) || 0); } catch (e) { return false; }
  }

  /* Écran de pause plein écran. Deux usages : une RECHERCHE qui contient un mot-clé,
   * et un SITE entier dont le nom de domaine contient un mot-clé (nike.com → « nike »). */
  function showBlockScreen(hit, texte, type) {
    if (document.getElementById('worthit-search-block')) return;
    const site = type === 'site';
    const etiquette = site ? wt('b.siteLabel') : wt('b.searchLabel');
    const titre = site ? wt('b.siteTitle', { site: esc(texte) }) : wt('b.searchTitle', { q: esc(texte) });
    const strict = strictActive();
    const host = document.createElement('div');
    host.id = 'worthit-search-host';
    host.innerHTML = `
      <div id="worthit-search-block" style="position:fixed;inset:0;z-index:2147483647;display:flex;align-items:center;justify-content:center;padding:20px;background:rgba(5,3,10,.94);backdrop-filter:blur(14px);font-family:'Segoe UI',system-ui,sans-serif;">
        <div style="max-width:430px;width:100%;background:linear-gradient(165deg,#1a102c,#0c0716);border:1px solid rgba(167,139,250,.35);border-radius:22px;padding:32px 28px;box-shadow:0 40px 90px rgba(0,0,0,.6),0 0 50px rgba(124,58,237,.2);animation:worthitPop .45s cubic-bezier(.34,1.56,.64,1) both;">
          <div style="display:flex;align-items:center;gap:8px;margin-bottom:20px;">
            ${LOGO_MARK}
            <span style="color:#fff;font-size:16px;font-weight:800;letter-spacing:-.02em;">worthit</span>
            <span style="margin-left:auto;font-size:11px;color:rgba(255,255,255,.4);">${etiquette}</span>
          </div>
          <h2 style="color:#fff;font-size:20px;font-weight:800;margin:0 0 12px;line-height:1.35;">${titre}</h2>
          <p style="color:rgba(255,255,255,.62);font-size:14px;line-height:1.6;margin:0 0 24px;">
            ${wt('b.reason', { mot: esc(hit) })}<br/>
            ${wt('b.unchanged')}
          </p>
          <div style="display:flex;flex-direction:column;gap:9px;">
            <button id="worthit-sb-leave" style="padding:14px;border-radius:13px;border:none;cursor:pointer;background:linear-gradient(135deg,#a78bfa,#7c3aed);color:#fff;font-size:14.5px;font-weight:700;font-family:inherit;">${strict ? wt('o.back') : wt('b.leave')}</button>
            ${strict
              ? pinGateHtml('worthit-sb')
              : `<button id="worthit-sb-stay" style="padding:12px;border-radius:13px;border:1px solid rgba(255,255,255,.18);cursor:pointer;background:transparent;color:rgba(255,255,255,.75);font-size:13px;font-family:inherit;">${wt('b.stay')}</button>`}
          </div>
          <p style="font-size:10.5px;color:rgba(255,255,255,.3);margin:18px 0 0;text-align:center;">${wt('o.footer')}</p>
        </div>
      </div>
      <style>@keyframes worthitPop{from{opacity:0;transform:scale(.6) translateY(30px);}to{opacity:1;transform:scale(1) translateY(0);}}</style>`;
    document.documentElement.appendChild(host);
    const prevOverflow = document.documentElement.style.overflow;
    document.documentElement.style.overflow = 'hidden';
    const close = () => { host.remove(); document.documentElement.style.overflow = prevOverflow; };
    document.getElementById('worthit-sb-leave').addEventListener('click', () => {
      close();
      if (history.length > 1) history.back(); else location.href = 'about:blank';
    });
    if (strict) {
      wirePinGate('worthit-sb', () => {
        try { sessionStorage.setItem(searchAllowKey, String(Date.now() + 5 * 60 * 1000)); } catch (e) {}
        close();
      });
    } else {
      document.getElementById('worthit-sb-stay').addEventListener('click', () => {
        try { sessionStorage.setItem(searchAllowKey, String(Date.now() + 5 * 60 * 1000)); } catch (e) {}
        close();
      });
    }
  }

  function esc(s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g,
      (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  }

  function checkBlockedSearch() {
    if (!cfg.enabled || cfg.blockSearch === false || isWorthitApp()) return;
    if (!(cfg.keywords || []).length) return;
    if (searchAllowedNow()) return;
    const q = currentSearchQuery().toLowerCase();
    if (!q) return;
    const hit = (cfg.keywords || []).find((k) => k && q.includes(String(k).toLowerCase()));
    if (hit) showBlockScreen(hit, currentSearchQuery(), 'search');
  }

  /* ---------- 2 ter) Blocage du site entier ----------
   * Flouter les produits un par un ne tient pas sur une vraie boutique : le nom du
   * produit n'est pas toujours dans le texte du lien, la grille se recharge sans arrêt,
   * et il reste toujours une image qui passe. Si le nom de domaine contient un mot-clé
   * bloqué (nike.com → « nike »), on arrête tout à l'entrée. */
  function domaineCourant() {
    return String(location.hostname || '').toLowerCase().replace(/^www\./, '');
  }
  function motCleDuDomaine() {
    if (!cfg.enabled || cfg.blockSites === false) return null;
    const h = domaineCourant();
    if (!h || isWorthitApp()) return null;
    // Trois lettres minimum pour bloquer un domaine : un mot-clé de deux lettres (« tv »,
    // une faute de frappe) se retrouve dans une bonne partie du web et bloquerait tout.
    return (cfg.keywords || []).find((k) => {
      const mot = String(k || '').toLowerCase().trim();
      return mot.length >= 3 && h.includes(mot);
    }) || null;
  }
  function checkBlockedSite() {
    if (searchAllowedNow()) return false;         // échappatoire 5 min déjà accordée
    const hit = motCleDuDomaine();
    if (!hit) return false;
    showBlockScreen(hit, domaineCourant(), 'site');
    return true;
  }

  // Google & co changent l'URL sans recharger la page : on surveille aussi les changements d'URL.
  let lastUrl = location.href;
  setInterval(() => {
    if (location.href !== lastUrl) {
      lastUrl = location.href;
      checkBlockedSite();
      checkBlockedSearch();
      // Les boutiques en SPA changent d'URL sans recharger : on revérifie aussi le panier/paiement.
      if (typeof checkPageAchat === 'function') setTimeout(checkPageAchat, 900);
    }
  }, 800);

  /* ---------- 1) Pause à l'achat ---------- */
  function detectPrice(el) {
    const re = /(\d{1,4}(?:[  .,]\d{3})*(?:[.,]\d{2})?)\s?(?:€|EUR)|(?:€|EUR)\s?(\d{1,4}(?:[.,]\d{2})?)/;
    let node = el;
    for (let d = 0; d < 6 && node; d++, node = node.parentElement) {
      const m = (node.innerText || '').match(re);
      if (m) return parseFloat((m[1] || m[2]).replace(/[  ]/g, '').replace(',', '.')) || 0;
    }
    const m = (document.body.innerText || '').match(re);
    return m ? parseFloat((m[1] || m[2]).replace(/[  ]/g, '').replace(',', '.')) || 0 : 0;
  }

  /* Worthy n'est disponible que pour les Premium, et seulement si le site a déjà synchronisé
   * le contexte budgétaire + l'URL du serveur (donc après une visite connectée sur Worthit). */
  function worthyActive() {
    return !!(cfg.premium && cfg.apiBase && cfg.ctx);
  }

  /* Anime le mini-échange dans l'overlay : Worthy pose une question personnalisée,
   * l'utilisateur répond, Worthy relance une fois. Deux tours de Worthy au maximum. */
  function runWorthy(price, kwHit) {
    const thread = document.getElementById('ww-thread');
    const input = document.getElementById('ww-input');
    const send = document.getElementById('ww-send');
    if (!thread || !input || !send) return;
    const history = [];
    let tours = 0;
    const MAX = 2;

    const bulle = (who, text) => {
      const div = document.createElement('div');
      const bot = who === 'bot';
      div.style.cssText = 'max-width:88%;padding:9px 12px;border-radius:13px;font-size:13px;line-height:1.5;white-space:pre-wrap;' + (bot
        ? 'align-self:flex-start;background:rgba(167,139,250,.14);border:1px solid rgba(167,139,250,.3);color:#fff;'
        : 'align-self:flex-end;background:rgba(255,255,255,.08);color:rgba(255,255,255,.85);');
      div.textContent = text;
      thread.appendChild(div);
      thread.scrollTop = thread.scrollHeight;
      return div;
    };

    const ask = (message) => new Promise((resolve) => {
      wapi.runtime.sendMessage({
        type: 'worthy-nudge', apiBase: cfg.apiBase,
        body: { message, history: history.slice(-8), context: cfg.ctx, premiumAuth: cfg.premiumAuth },
      }, (res) => {
        if (wapi.runtime.lastError || !res || res.error || !res.reply) return resolve(null);
        resolve(res.reply);
      });
    });

    const item = kwHit || (document.title || '').slice(0, 60) || wt('o.thisPurchase');
    // Le message est écrit dans la langue de l'utilisateur : c'est aussi ce qui indique
    // à Worthy dans quelle langue répondre, en plus du contexte envoyé au serveur.
    const premierMsg = price > 0 ? wt('w.askPrice', { item, prix: price }) : wt('w.ask', { item });

    const loading = bulle('bot', wt('w.thinking'));
    ask(premierMsg).then((reply) => {
      history.push({ who: 'user', text: premierMsg });
      // Repli hors-ligne : si l'IA ne répond pas, Worthy garde une question honnête générique.
      loading.textContent = reply || wt('w.fallback1');
      if (reply) history.push({ who: 'bot', text: reply });
      tours = 1;
      input.disabled = false;
      input.placeholder = wt('w.yourAnswer');
      input.focus();
    });

    const repondre = () => {
      if (input.disabled) return;
      const v = (input.value || '').trim();
      if (!v || tours >= MAX) return;
      bulle('user', v);
      history.push({ who: 'user', text: v });
      input.value = ''; input.disabled = true; input.placeholder = wt('w.thinking');
      const l2 = bulle('bot', wt('w.thinking'));
      ask(v).then((reply) => {
        l2.textContent = reply || wt('w.fallback2');
        if (reply) history.push({ who: 'bot', text: reply });
        tours++;
        if (tours < MAX) { input.disabled = false; input.placeholder = wt('w.yourAnswer'); input.focus(); }
        else { input.placeholder = wt('w.said'); send.disabled = true; send.style.opacity = '.4'; send.style.cursor = 'default'; }
      });
    };
    send.addEventListener('click', repondre);
    input.addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); repondre(); } });
  }

  function overlayHtml(price, kwHit, wait, strict, worthy) {
    // Le symbole ne se place pas au même endroit selon la langue : « 149 € » mais « €149 ».
    // Sans montant, on change carrément de phrase : injecter « cet achat » là où la tournure
    // attend une somme donnait « Tu allais dépenser cet achat. », cassé dans les 5 langues.
    const titre = price > 0
      ? wt('o.title', { prix: `<strong>${wt('o.price', { n: price.toLocaleString(self.WorthitI18n.locale()) })}</strong>` })
      : wt('o.titleNoPrice');
    const reason = kwHit
      ? wt('o.reasonKw', { mot: esc(kwHit) })
      : (cfg.priceLimit > 0 && price >= cfg.priceLimit
        ? wt('o.reasonLimit', { seuil: cfg.priceLimit })
        : wt('o.reasonGeneric'));
    // Premium : au lieu du texte figé, un vrai échange avec Worthy (rempli en asynchrone).
    const corps = worthy
      ? `<div id="worthit-worthy" style="margin:0 0 20px;">
           <div id="ww-thread" style="display:flex;flex-direction:column;gap:8px;max-height:210px;overflow-y:auto;margin-bottom:10px;"></div>
           <div id="ww-inputrow" style="display:flex;gap:7px;">
             <input id="ww-input" disabled placeholder="${wt('w.thinking')}" style="flex:1;background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.14);border-radius:11px;padding:9px 11px;color:#fff;font-size:13px;font-family:inherit;outline:none;"/>
             <button id="ww-send" style="padding:9px 13px;border-radius:11px;border:none;cursor:pointer;background:linear-gradient(135deg,#a78bfa,#7c3aed);color:#fff;font-size:14px;font-family:inherit;">→</button>
           </div>
         </div>`
      : `<p style="color:rgba(255,255,255,.62);font-size:14px;line-height:1.6;margin:0 0 22px;">${reason}<br/>${wt('o.honest')}</p>`;
    return `
      <div id="worthit-overlay" style="position:fixed;inset:0;z-index:2147483647;display:flex;align-items:center;justify-content:center;padding:20px;background:rgba(5,3,10,.82);backdrop-filter:blur(6px);font-family:'Segoe UI',system-ui,sans-serif;">
        <div style="max-width:400px;width:100%;background:linear-gradient(165deg,#1a102c,#0c0716);border:1px solid rgba(167,139,250,.35);border-radius:22px;padding:30px 26px;box-shadow:0 40px 90px rgba(0,0,0,.6),0 0 50px rgba(124,58,237,.2);animation:worthitPop .45s cubic-bezier(.34,1.56,.64,1) both;">
          <div style="display:flex;align-items:center;gap:8px;margin-bottom:18px;">
            ${LOGO_MARK}
            <span style="color:#fff;font-size:16px;font-weight:800;letter-spacing:-.02em;">worthit</span>
            <span style="margin-left:auto;font-size:11px;color:rgba(255,255,255,.4);">${worthy ? wt('o.eyebrowWorthy') : wt('o.eyebrowPause')}</span>
          </div>
          <h2 style="color:#fff;font-size:19px;font-weight:800;margin:0 0 ${worthy ? '16' : '10'}px;line-height:1.35;">${titre}</h2>
          ${corps}
          <div style="display:flex;flex-direction:column;gap:9px;">
            <button id="worthit-wait" style="padding:14px;border-radius:13px;border:none;cursor:pointer;background:linear-gradient(135deg,#a78bfa,#7c3aed);color:#fff;font-size:14.5px;font-weight:700;font-family:inherit;">${strict ? wt('o.back') : wt('o.wait24')}</button>
            ${strict
              ? pinGateHtml('worthit')
              : `<button id="worthit-buy" ${wait > 0 ? 'disabled' : ''} style="padding:12px;border-radius:13px;border:1px solid rgba(255,255,255,.18);cursor:${wait > 0 ? 'not-allowed' : 'pointer'};background:transparent;color:rgba(255,255,255,${wait > 0 ? '.38' : '.75'});font-size:13px;font-family:inherit;transition:color .3s ease;">${wait > 0 ? wt('o.buyIn', { n: wait }) : wt('o.buyAnyway')}</button>`}
          </div>
          <p style="font-size:10.5px;color:rgba(255,255,255,.3);margin:16px 0 0;text-align:center;">${wt('o.footer')}</p>
        </div>
      </div>
      <style>@keyframes worthitPop{from{opacity:0;transform:scale(.6) translateY(30px);}to{opacity:1;transform:scale(1) translateY(0);}}</style>`;
  }

  function showOverlay(target, price, kwHit) {
    if (document.getElementById('worthit-overlay')) return;
    const strict = strictActive();
    // Worthy (Premium) : mini-échange personnalisé, mais pas en mode strict (là, c'est le PIN qui compte).
    const worthy = !strict && worthyActive();
    // En mode strict, on ne passe qu'avec le code : le minuteur n'a plus lieu d'être.
    let wait = strict ? 0 : Math.min(600, Math.max(0, Math.round(+cfg.pauseSeconds || 0)));
    const host = document.createElement('div');
    host.innerHTML = overlayHtml(price, kwHit, wait, strict, worthy);
    document.documentElement.appendChild(host);
    if (worthy) runWorthy(price, kwHit);

    let timer = null;
    const cleanup = () => { if (timer) clearInterval(timer); host.remove(); };
    const proceed = () => {
      cleanup();
      // Tu achètes finalement ce produit : on annule la résistance en attente pour cette URL.
      cancelResistance();
      try { sessionStorage.setItem(allowKey, String(Date.now() + 10000)); } catch (e) {}
      if (target) target.click();
    };

    document.getElementById('worthit-wait').addEventListener('click', () => {
      cleanup();
      if (strict) return; // « ← Retour » : on reste sur la page, sans badge de série
      // Tu résistes : on note l'économie en attente (confirmée après 24 h, dédup par URL).
      recordResistance(price);
      const badge = document.createElement('div');
      badge.textContent = wt('o.streak');
      badge.style.cssText = 'position:fixed;bottom:24px;right:24px;z-index:2147483647;background:#1a102c;border:1px solid rgba(167,139,250,.4);color:#fff;padding:12px 18px;border-radius:999px;font-family:system-ui;font-size:13.5px;box-shadow:0 12px 30px rgba(0,0,0,.5);';
      document.documentElement.appendChild(badge);
      setTimeout(() => badge.remove(), 3500);
    });

    if (strict) {
      wirePinGate('worthit', proceed);
      return;
    }

    const buyBtn = document.getElementById('worthit-buy');
    // Résister est toujours instantané ; c'est seulement « J'achète quand même » qui doit patienter.
    if (wait > 0) {
      timer = setInterval(() => {
        wait--;
        if (wait > 0) {
          buyBtn.textContent = wt('o.buyIn', { n: wait });
        } else {
          clearInterval(timer); timer = null;
          buyBtn.disabled = false;
          buyBtn.textContent = wt('o.buyAnyway');
          buyBtn.style.cursor = 'pointer';
          buyBtn.style.color = 'rgba(255,255,255,.75)';
        }
      }, 1000);
    }
    buyBtn.addEventListener('click', () => {
      if (buyBtn.disabled) return; // le minuteur n'est pas terminé
      proceed();
    });
  }

  /* Beaucoup de boutons d'achat n'ont pas de texte : icône seule, bouton Apple Pay/PayPal,
   * image cliquable. On ratisse donc plusieurs sources avant de conclure. */
  function labelOf(el) {
    if (!el) return '';
    let s = (el.innerText || '').trim();
    if (!s) s = (el.value || '').trim();
    if (!s) {
      const img = el.querySelector && el.querySelector('img[alt]');
      s = (el.getAttribute('aria-label') || el.getAttribute('title') || el.getAttribute('name') ||
           el.getAttribute('data-testid') || el.getAttribute('id') ||
           (img && img.getAttribute('alt')) || '').trim();
    }
    return s.slice(0, 160);
  }

  function pauseAvantAchat(cible, e) {
    let until = 0;
    try { until = +sessionStorage.getItem(allowKey) || 0; } catch (err) {}
    if (Date.now() < until) return false;

    const pageText = (document.title + ' ' + location.href + ' ' + labelOf(cible)).toLowerCase();
    const kwHit = (cfg.keywords || []).find((k) => k && pageText.includes(String(k).toLowerCase()));
    const price = detectPrice(cible || document.body);
    const priceHit = cfg.priceLimit > 0 && price >= cfg.priceLimit;
    if (!(cfg.pauseAll || kwHit || priceHit)) return false;

    if (e) { e.preventDefault(); e.stopImmediatePropagation(); }
    showOverlay(cible, price, kwHit);
    return true;
  }

  /* Un prix VRAIMENT à côté de l'élément — contrairement à detectPrice(), qui se rabat sur
   * la page entière et trouve donc toujours quelque chose sur un site marchand.
   * Ici c'est un indice de contexte : un bouton « Buy » collé à un prix est un vrai bouton
   * d'achat ; un onglet « Buy » de barre de navigation n'a aucun prix autour de lui. */
  function prixJusteACote(el) {
    const re = /(\d{1,4}(?:[  .,]\d{3})*(?:[.,]\d{2})?)\s?(?:€|EUR|\$|£)|(?:€|EUR|\$|£)\s?\d/i;
    let node = el;
    for (let d = 0; d < 3 && node && node !== document.body; d++, node = node.parentElement) {
      if (re.test(node.innerText || '')) return true;
    }
    return false;
  }

  /* Un mot faible ne suffit pas : il faut un signe que c'est bien une action de paiement,
   * pas un lien de catalogue. Rejeté d'office dans une barre de navigation ou des onglets. */
  function estActionDachat(el) {
    if (!el || !el.closest) return false;
    // On y parcourt, on n'y paie pas.
    if (el.closest('nav, [role="navigation"], [role="menubar"], [role="tablist"], [role="tab"], [aria-label*="breadcrumb" i], .breadcrumb')) return false;
    // Déjà sur une page panier/paiement : le moindre bouton d'achat y est crédible.
    try { if (CHECKOUT_PATHS.test(new URL(location.href).pathname)) return true; } catch (err) {}
    // Un lien qui mène explicitement au panier ou au paiement : sans équivoque.
    const href = el.getAttribute('href');
    if (href && CHECKOUT_PATHS.test(href)) return true;
    // Un vrai contrôle d'action plutôt qu'un lien de catalogue. Nécessaire, pas suffisant.
    const tag = (el.tagName || '').toUpperCase();
    const estControle = tag === 'BUTTON' || (tag === 'INPUT' && /^(submit|button|image)$/i.test(el.type || ''));
    if (!estControle) return false;
    // Et il faut encore un prix à proximité. Être un <button> ne prouvait rien : dans une
    // interface, presque tout ce qui se clique en est un. Un jeu proposant « Y aller et
    // régler ça en face » ouvrait ainsi une pause anti-achat en pleine partie.
    return prixJusteACote(el);
  }

  document.addEventListener('click', (e) => {
    if (!cfg.enabled || isWorthitApp()) return;
    const btn = e.target && e.target.closest && e.target.closest(
      'button, a, input[type="submit"], input[type="button"], [role="button"], [class*="buy" i], [class*="checkout" i], [class*="panier" i], [id*="buy" i], [id*="checkout" i]');
    if (!btn) return;
    const libelle = labelOf(btn);
    // Une formulation sans ambiguïté déclenche la pause immédiatement.
    // Un simple verbe doit d'abord prouver qu'il s'agit d'une action de paiement.
    if (!ACHAT_FORT.test(libelle)) {
      if (!ACHAT_FAIBLE.test(libelle)) return;
      if (!estActionDachat(btn)) return;
    }
    pauseAvantAchat(btn, e);
  }, true);

  /* Certains sites valident l'achat par soumission de formulaire (bouton image, Entrée au clavier)
   * sans qu'un clic sur un bouton reconnaissable ne passe : on intercepte aussi le submit. */
  document.addEventListener('submit', (e) => {
    if (!cfg.enabled || isWorthitApp()) return;
    const form = e.target;
    if (!form || !form.matches) return;
    const indice = (labelOf(form) + ' ' + (form.getAttribute('action') || '')).toLowerCase();
    if (!BUY_WORDS_STRICT.test(indice) && !CHECKOUT_PATHS.test(form.getAttribute('action') || '')) return;
    // On resoumettra le formulaire si l'utilisateur confirme, plutôt que de « cliquer » un bouton.
    pauseAvantAchat({ click: () => form.submit(), closest: () => null, querySelector: () => null,
                      getAttribute: (a) => form.getAttribute(a), innerText: labelOf(form) }, e);
  }, true);

  /* Arriver directement sur une page panier/paiement est déjà un chemin d'achat :
   * on impose la pause aussi là, une seule fois par page. */
  let checkoutVu = '';
  function checkPageAchat() {
    if (!cfg.enabled || isWorthitApp() || !cfg.pauseAll) return;
    if (document.getElementById('worthit-overlay')) return;
    let chemin = '';
    try { chemin = new URL(location.href).pathname; } catch (e) { return; }
    if (!CHECKOUT_PATHS.test(chemin)) return;
    if (checkoutVu === chemin) return; // déjà proposé pour cette page
    let until = 0;
    try { until = +sessionStorage.getItem(allowKey) || 0; } catch (err) {}
    if (Date.now() < until) return;
    checkoutVu = chemin;
    // Pas de cible à re-cliquer : l'utilisateur reste simplement sur la page s'il confirme.
    showOverlay(null, detectPrice(document.body), null);
  }
  setTimeout(checkPageAchat, 1800);

  /* ---------- chargement des réglages (en dernier : toutes les fonctions sont prêtes) ---------- */
  wapi.storage.sync.get(['worthitCfg'], (r) => {
    if (r && r.worthitCfg) cfg = Object.assign(cfg, r.worthitCfg);
    self.WorthitI18n.setLang(cfg.lang);   // la langue du compte l'emporte sur celle du navigateur
    publierEtatVersSite();                // l'appli affiche l'état réel du mode strict
    if (checkBlockedSite()) return;
    checkBlockedSearch();
    maskProducts();
  });
  wapi.storage.onChanged.addListener((changes) => {
    if (changes.worthitCfg && changes.worthitCfg.newValue) {
      cfg = Object.assign(cfg, changes.worthitCfg.newValue);
      self.WorthitI18n.setLang(cfg.lang);
      if (checkBlockedSite()) return;
      checkBlockedSearch();
      maskProducts();
    }
  });
})();
